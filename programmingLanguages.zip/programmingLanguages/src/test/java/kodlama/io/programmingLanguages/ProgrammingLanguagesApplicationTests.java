package kodlama.io.programmingLanguages;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgrammingLanguagesApplicationTests {

	@Test
	void contextLoads() {
	}

}
